# S&B Forge (`sb-forge`)
> **Autarkic Pipeline Runner, Secret Manager & Deployment Tool**  
> 100% Pure-Rust · Single-Binary · Zero-Plaintext-on-Disk · Built on S&B NetGate (`sb-ssh`)  
> *Sicherheitsmarke: Skulls & Bones ([skulls-and-bones.org](https://www.skulls-and-bones.org))*

[![Rust](https://img.shields.io/badge/Language-Rust_2021-orange.svg?style=flat-square)](https://www.rust-lang.org/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg?style=flat-square)](LICENSE)
[![Cost](https://img.shields.io/badge/Cost-100%25_Free_%26_Open--Source-brightgreen.svg?style=flat-square)](#)
[![Compliance](https://img.shields.io/badge/BSI_IT--Grundschutz-OPS.1.1.4-brightgreen.svg?style=flat-square)](https://www.bsi.bund.de)
[![Zero-Dependency](https://img.shields.io/badge/Dependencies-100%25_Pure--Rust-blueviolet.svg?style=flat-square)](#)

---

## ⚡ Das Problem mit herkömmlichem CI/CD & Secret-Management

* **`.env`-Dateien im Dateisystem:** Entwickler legen sensible Tokens (`DATABASE_URL`, Stripe Keys, API-Keys) im Klartext in `.env`-Dateien ab. Ein fehlerhafter `git add .` reicht aus, um Secrets öffentlich zu exposen.
* **Schwere CI/CD-Monolithen & Cloud-Lock-in:** Bestehende CI/CD-Tools erfordern oft Docker-Daemons, komplexe YAML-Konfigurationen oder teure SaaS-Cloud-Abos.
* **Ungesicherte Server-Bereitstellung:** Secrets werden auf Servern häufig unverschlüsselt in Umgebungsvariablen-Dateien oder Systemd-Units abgelegt.
* **Mangelndes Audit:** Wer hat wann auf welche Secrets zugegriffen und welche Pipelines auf welchem Server ausgeführt?

---

## 🛡️ Die Lösung: S&B Forge

**S&B Forge (`sb-forge`)** vereint Task-Runner, CI/CD-Pipelines und Secret-Management in einer einzigen, autarken Rust-Binary:

1. **Verschlüsselter Local Vault:** Alle Secrets werden mit **AES-256-GCM** und **Argon2id-Schlüsselableitung** in `~/.sb-forge/vault/<env>.vault` verschlüsselt gespeichert. **Null Klartext auf der Festplatte.**
2. **In-Memory Prozess-Injektion (`sb-forge exec`):** Secrets werden zur Laufzeit direkt und transparent in den RAM des Kindprozesses injiziert. Web-Stacks (Node.js, React, Flask, Python, Go) greifen über gewohnte Umgebungsvariablen (`process.env.KEY`, `os.environ["KEY"]`) zu, ohne dass je eine Datei geschrieben werden muss.
3. **Cryptographic Server Sealing (`sb-forge env seal`):** Secrets werden für den Zielserver kryptographisch versiegelt (`env.sealed`), an den SSH-Server-Fingerprint gebunden und via **S&B NetGate (`sb-ssh push`)** übertragen.
4. **Parallele DAG-Pipelines:** Asynchrone Stage-Ausführung mit Tokio, topologischer DAG-Dependency-Resolver (`depends_on`) mit Zykluserkennung und File-Watching.
5. **Ratatui TUI Dashboard:** Interaktiver Vollbild-Monitor (`sb-forge watch`) zur Überwachung von Pipeline-Durchläufen, Fehlerschritten und Vault-Sicherheit.
6. **BSI IT-Grundschutz (OPS.1.1.4):** Revisionssichere JSONL-Audit-Logs (`runs.jsonl`, `secrets.jsonl`) mit SIEM-Export (`--json`).

---

## 🚀 Architektur

```
┌────────────────────────────────────────────────────────────────────────┐
│                          S&B FORGE ENGINE                              │
│                                                                        │
│   Forge.toml ──► DAG Resolver ──► Tokio Tasks (parallel = true)        │
│       │                                │                               │
│       ▼                                ▼                               │
│  AES-256 Vault ──► RAM-Only Secret ──► Process (sb-forge exec)         │
│  (Argon2id KDF)    Injection           Child Process Env               │
│       │                                                                │
│       ▼                                                                │
│  Cryptographic ──► Sealed Envelope ──► sb-ssh SFTP Push ──► Server     │
│  Server Seal       (env.sealed)        & Remote Exec        Runtime    │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 📦 Installation & Schnellstart

### 1. Aus Quellcode installieren (Cargo)
```bash
# Repository klonen
git clone https://github.com/Skulls-and-Bones/sb-forge.git
cd sb-forge

# Global installieren
cargo install --path . --force
```

### 2. Projekt initialisieren
Erstellt ein `Forge.toml`-Template, sichert `.gitignore` ab und installiert den Git Pre-Commit Hook:
```bash
cd my-project
sb-forge init
```

### 3. Secrets sicher hinterlegen
```bash
# Interaktiv mit verdeckter Eingabe
sb-forge secret set DATABASE_URL --env dev

# Secrets anzeigen (Namen & Versionen, Werte bleiben geschützt)
sb-forge secret list --env dev
```

### 4. Anwendung mit In-Memory Secrets starten
```bash
# Injiziert alle dev-Secrets transparent in den Prozess
sb-forge exec -- node server.js
```

### 5. Pipelines & Rezepte ausführen
```bash
# Einzelnes Rezept ausführen
sb-forge run check

# Vollständige Pipeline ausführen
sb-forge run ci

# Mit automatischem Datei-Reload (Watch-Mode)
sb-forge run check --watch
```

### 6. Produktions-Deployment mit Server-Sealing
```bash
# Versiegelt Secrets für den Server und überträgt das Paket via sb-ssh
sb-forge env seal prod --server hostinger-prod --deploy

# BSI-gehärtete systemd Service-Unit für den Server generieren
sb-forge systemd-unit app --env prod --user www-data
```

### 7. Interaktives TUI Dashboard öffnen
```bash
sb-forge watch
```

---

## 📝 `Forge.toml` Spezifikation

```toml
[forge]
name = "my-application"
version = "1.0.0"

# ── DEFINIERTE SECRETS (Werte liegen verschlüsselt im Vault) ─────────────────
[secret.database_url]
description  = "PostgreSQL Connection String"
environments = ["dev", "staging", "prod"]
inject_as    = "DATABASE_URL"
rotate_every = "90d"

# ── NICHT-SENSIBLE KONFIGURATION ─────────────────────────────────────────────
[config.dev]
NODE_ENV = "development"
PORT     = "3000"

[config.prod]
NODE_ENV = "production"
PORT     = "8080"

# ── ATOMARE REZEPTE (TASKS) ──────────────────────────────────────────────────
[recipe.lint]
description = "Code-Formatierung und Linting"
run = ["npm run lint"]

[recipe.test]
description = "Unit-Tests ausführen"
depends_on = ["lint"]
run = ["npm test"]

[recipe.build]
description = "Produktions-Build erstellen"
depends_on = ["test"]
run = ["npm run build"]

# SFTP File Upload via sb-ssh
[recipe.upload]
description = "Build-Artefakte via SFTP hochladen"
server = "hostinger-prod"
action = "push"
local = "./dist/app.tar.gz"
remote = "/var/www/app/app.tar.gz"

# Remote Execution via sb-ssh
[recipe.restart]
description = "Service auf Server neustarten und prüfen"
server = "hostinger-prod"
run = ["sudo systemctl restart app"]
health_check = "systemctl is-active app"

# ── PIPELINES (GEORDNETE STAGES) ──────────────────────────────────────────────
[pipeline.ci]
description = "Continuous Integration Pipeline"
stages = [
  { name = "Quality Gate", recipes = ["lint", "test"], parallel = true },
  { name = "Compile",      recipes = ["build"] }
]

[pipeline.deploy]
description = "Vollständiges Produktions-Deployment"
stages = [
  { name = "Build",        recipes = ["build"] },
  { name = "Transfer",     recipes = ["upload"] },
  { name = "Verification", recipes = ["restart"] }
]
```

---

## 🛠️ CLI Befehlsübersicht

| Befehl | Beschreibung |
| :--- | :--- |
| `sb-forge init` | Forge im aktuellen Projekt initialisieren (Forge.toml, .gitignore, Git Hooks) |
| `sb-forge secret set <name> --env <env>` | Secret verschlüsselt im AES-256-GCM Vault hinterlegen |
| `sb-forge secret get <name> --env <env>` | Secret-Wert im Klartext abrufen (erfordert aktiven Login) |
| `sb-forge secret list [--env <env>]` | Hinterlegte Secrets auflisten (ohne Klartext-Werte) |
| `sb-forge secret rotate <name> --env <env>` | Secret rotieren mit Versionshistorie |
| `sb-forge secret delete <name> --env <env>` | Secret aus dem Vault entfernen |
| `sb-forge env activate <env>` | Standard-Environment für aktuelle Shell-Sitzung setzen |
| `sb-forge env seal <env> --server <server>` | Secrets server-spezifisch versiegeln (`env.sealed`) & via SFTP übertragen |
| `sb-forge run <recipe\|pipeline>` | Rezept oder Pipeline ausführen (automatische Auflösung) |
| `sb-forge run <name> --watch` | Dateiüberwachung mit automatischem Task-Neustart bei Änderungen |
| `sb-forge run <name> --dry-run` | Zeigt geplante Ausführungsschritte an, ohne Befehle zu starten |
| `sb-forge exec --env <env> -- <cmd>` | Beliebigen Prozess mit injizierten RAM-Secrets starten |
| `sb-forge scan` | Scannt Projektdateien auf Secret-Leaks (9 Regex-Pattern) |
| `sb-forge scan --staged` | Git-Staged Scan (wird vom Pre-Commit Hook ausgeführt) |
| `sb-forge watch` | Ratatui TUI Live-Dashboard öffnen |
| `sb-forge audit` | BSI IT-Grundschutz Revisionsprotokoll anzeigen |
| `sb-forge audit --json` | Audit-Log als SIEM-kompatible JSON-Lines exportieren |
| `sb-forge check` | Secret-Lifecycle & Rotation-Drift prüfen |
| `sb-forge check --git-history` | Durchsucht die gesamte Git-Historie nach versehentlich committeten Secrets |
| `sb-forge hooks install` | Git Pre-Commit Hook im Repository installieren |
| `sb-forge completions <shell>` | Shell-Autovervollständigung für PowerShell, Bash, Zsh, Fish, Elvish |

---

## 🔒 Sicherheitsarchitektur & Compliance

* **Kryptographie:** AES-256-GCM mit 96-Bit Nonce und 128-Bit Authentifizierungs-Tag. Schlüsselableitung über Argon2id mit projektspezifischem Salt.
* **In-Memory Zeroization:** Sensitive Schlüssel und Klartexte werden nach Prozessende im Speicher überschrieben.
* **Server-Fingerprint Binding:** Ein mit `sb-forge env seal` erstellter Umschlag lässt sich nur auf dem Zielserver mit dessen Host-Identität entschlüsseln.
* **BSI IT-Grundschutz (OPS.1.1.4):** Alle Zugriffe auf Secrets sowie Pipeline-Durchläufe werden mit ISO 8601-Zeitstempel, Operator-ID und Status revisionssicher protokolliert.

---

## 📄 Lizenz & Urheberrecht

Veröffentlicht unter der [MIT License](LICENSE).  
Entwickelt von **Skulls & Bones Lab** ([skulls-and-bones.org](https://www.skulls-and-bones.org)).
Freie Software für private und kommerzielle Infrastrukturen.

